#!/bin/sh
tail -f log/agent.log
